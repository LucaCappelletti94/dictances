"""Current version of package dictances"""
__version__ = "1.5.1"